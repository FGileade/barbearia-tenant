import { BrowserRouter, Routes, Route, Navigate, useParams } from "react-router-dom";
import { TenantProvider, useTenant } from "./context/TenantContext";
import BookingHome from "./features/booking/BookingHome";
import BarberLogin from "./features/barber-portal/BarberLogin";
import BarberDashboard from "./features/barber-portal/BarberDashboard";

// Envolve as rotas do cliente com o TenantProvider, resolvendo a barbearia
// a partir do slug na URL: /b/{slug}/...
function ClientArea() {
  const { tenantSlug } = useParams<{ tenantSlug: string }>();
  if (!tenantSlug) return <Navigate to="/" replace />;

  return (
    <TenantProvider slug={tenantSlug}>
      <TenantGate />
    </TenantProvider>
  );
}

function TenantGate() {
  const { tenant, loading, error } = useTenant();

  if (loading) return <p className="status-message">Carregando barbearia…</p>;
  if (error || !tenant) {
    return <p className="status-message status-message--error">{error ?? "Barbearia não encontrada."}</p>;
  }
  return <BookingHome />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Área pública do cliente, sem login: escolhe profissional, serviço e horário */}
        <Route path="/b/:tenantSlug/*" element={<ClientArea />} />

        {/* Área do barbeiro/gestor de cada barbearia */}
        <Route path="/admin/:tenantSlug/login" element={<BarberLogin />} />
        <Route path="/admin/:tenantSlug/*" element={<BarberDashboard />} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
