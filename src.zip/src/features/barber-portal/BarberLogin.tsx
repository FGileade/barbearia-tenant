// Implementação completa (Firebase Auth por tenant) entra no Bloco 5.
export default function BarberLogin() {
  return (
    <main className="barber-login">
      <h1>Acesso do barbeiro/gestor</h1>
      <p>Em breve: login por e-mail e senha.</p>
    </main>
  );
}
