import { LogOut } from "lucide-react";
import { useBarberAuth } from "../../context/BarberAuthContext";
import NotificationOptIn from "./NotificationOptIn";
import "./barber-portal.css";

export default function BarberDashboard() {
  const { staff, logout } = useBarberAuth();
  if (!staff) return null;

  return (
    <div className="barber-dashboard">
      <header className="barber-dashboard__header">
        <h1 className="step__title">Painel da barbearia</h1>
        <button className="btn-ghost" onClick={logout}>
          <LogOut size={16} /> Sair
        </button>
      </header>

      <NotificationOptIn tenantId={staff.tenantId} />

      <p className="status-message">
        Agenda do dia, profissionais e serviços entram no próximo bloco.
      </p>
    </div>
  );
}
