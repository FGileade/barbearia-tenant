// Implementação completa (agenda do dia, gestão de profissionais e
// serviços) entra no Bloco 5.
export default function BarberDashboard() {
  return (
    <main className="barber-dashboard">
      <h1>Painel da barbearia</h1>
      <p>Em breve: agenda do dia, profissionais e serviços.</p>
    </main>
  );
}
